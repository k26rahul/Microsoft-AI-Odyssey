﻿using Azure;
using System;
using Azure.AI.TextAnalytics;

namespace ProofOfConcept
{
    class Program
    {
        private static readonly AzureKeyCredential credentials = new AzureKeyCredential("{REPLACE-WITH-YOUR-VALUE}");
        private static readonly Uri endpoint = new Uri("{REPLACE-WITH-YOUR-VALUE}");

        static void RecognizeYourText(TextAnalyticsClient client)
        {
            string document = "Call our office at 312-555-1234 and ask for Graham Barnes, or send an email to support@contoso.com.";
        
            var entities = client.null; // replace null with the correct method to recognize the requested information.

            Console.WriteLine($"Redacted Text: {entities.RedactedText}");
            if (entities.Count > 0)
            {
                Console.WriteLine($"Recognized {entities.Count} the following entities {(entities.Count > 1 ? "ies" : "y")}:");

                foreach (var entity in entities)
                {
                    Console.WriteLine($"Text: {entity.Text}, Category: {entity.Category}, SubCategory: {entity.SubCategory}, Confidence score: {entity.ConfidenceScore}");
                }
            }
            else
            {
                Console.WriteLine("No entities were found.");
            }
        }

        static void Main(string[] args)
        {
            var client = new TextAnalyticsClient(endpoint, credentials);
            RecognizeYourText(client);

            Console.Write("Press any key to exit.");
            Console.ReadKey();
        }

    }
}